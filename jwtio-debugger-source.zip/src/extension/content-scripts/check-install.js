const e = document.getElementById('extension-button');
if(e) {
    e.classList.add('is-installed');
}
