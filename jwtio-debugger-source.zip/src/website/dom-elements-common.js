export const codeElements = document.querySelectorAll('.plain-text pre code');
export const counterElement = document.querySelector('.counter');
