import { setupHighlighting } from "../highlighting.js";
import { setupJwtCounter } from "../counter.js";

// Initialization
setupHighlighting();
setupJwtCounter();
