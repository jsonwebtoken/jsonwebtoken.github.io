import 'source-map-support/register';

import './utils.js';
import './libraries.js';
import './editor';
